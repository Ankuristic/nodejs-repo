

export default class ProductController{

    getAllProducts(req,res){}

    addProduct(req, res){}

    rateProduct(req,res){}

    getOneProduct(req,res){}

}