// Note:  Please do not change the prewritten code

// import the required module here
const math = require("./math")

const Solution = () => {
    const nums = [1, 2, 3, 4, 5];
    // write your code here to Display the results of the calculations on the console.
 math.sum(nums)
   math.mean(nums)


};
Solution();

// console.log(4+5)
module.exports = Solution;
