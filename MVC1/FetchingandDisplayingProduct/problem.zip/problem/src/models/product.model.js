// Import the necessary modules here
// import path from 'path'
import Product from '../assets/products'

export default class ProductModel {
  fetchProducts = () => {
    // Write your code here
    console.log("product",Product);
 return Product
  };
}




